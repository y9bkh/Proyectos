package _1er_Trimestre;

public class ejemplo2_runtime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String so = System.getProperty("os.name");
		String comando;
		// Determinar comando Windows o Linux
		if (so.equals("Linux")) {
		    // Some code here
		} else {
		   // Some other code here
		}
	}

}
